<img src="{{ asset('logo of cpc.png') }}" alt="CPC Logo" class="h-16 w-auto">
