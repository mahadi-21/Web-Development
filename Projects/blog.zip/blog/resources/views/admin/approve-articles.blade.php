<x-admin-layout>
    <div>
        <h1 class="text-2xl font-bold mb-4">Admin Dashboard</h1>
        <p>Welcome to the admin dashboard! Here you can manage your blog posts, categories, and users.</p>
    </div>
</x-admin-layout>