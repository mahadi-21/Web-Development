<x-admin-layout>
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
        <div class="max-w-7xl mx-auto py-12 px-4 sm:py-16 sm:px-6 lg:px-8">
            <div class="flex justify-between items-center">
                <div>
                    <h1 class="text-4xl font-extrabold sm:text-5xl md:text-6xl">Create Category</h1>
                    <p class="mt-4 text-xl text-indigo-100">Add a new category to organize your content</p>
                </div>
                <div>
                    <a href="{{ route('admin.categories') }}"
                        class="inline-block bg-white text-indigo-600 px-6 py-3 rounded-lg hover:bg-indigo-50 transition font-medium shadow-lg">
                        Back to Categories
                    </a>
                </div>
            </div>
        </div>
    </div>

    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-900">Category Details</h3>
            </div>

            <form action="{{ route('admin.categories.store') }}" method="POST" class="p-6">
                @csrf

                <!-- Name -->
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-medium mb-2">Category Name *</label>
                    <input type="text" name="name" value="{{ old('name') }}"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 @error('name') border-red-500 @enderror"
                        placeholder="e.g., Technology">
                    @error('name')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                

                <!-- Description -->
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-medium mb-2">Description</label>
                    <textarea name="description" rows="3"
                        class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 @error('description') border-red-500 @enderror"
                        placeholder="Category description...">{{ old('description') }}</textarea>
                    @error('description')
                        <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                    @enderror
                </div>

                <!-- Icon and Color -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    {{-- <div>
                        <label class="block text-gray-700 text-sm font-medium mb-2">Icon *</label>
                        <select name="icon"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 @error('icon') border-red-500 @enderror">
                            <option value="">Select an icon</option>
                            <option value="laptop-code" {{ old('icon') == 'laptop-code' ? 'selected' : '' }}>💻 Technology
                            </option>
                            <option value="heart" {{ old('icon') == 'heart' ? 'selected' : '' }}>❤️ Lifestyle</option>
                            <option value="plane" {{ old('icon') == 'plane' ? 'selected' : '' }}>✈️ Travel</option>
                            <option value="utensils" {{ old('icon') == 'utensils' ? 'selected' : '' }}>🍔 Food</option>
                            <option value="heart-pulse" {{ old('icon') == 'heart-pulse' ? 'selected' : '' }}>🏥 Health
                            </option>
                            <option value="briefcase" {{ old('icon') == 'briefcase' ? 'selected' : '' }}>💼 Business
                            </option>
                            <option value="futbol" {{ old('icon') == 'futbol' ? 'selected' : '' }}>⚽ Sports</option>
                            <option value="film" {{ old('icon') == 'film' ? 'selected' : '' }}>🎬 Entertainment</option>
                            <option value="flask" {{ old('icon') == 'flask' ? 'selected' : '' }}>🔬 Science</option>
                            <option value="palette" {{ old('icon') == 'palette' ? 'selected' : '' }}>🎨 Art</option>
                            <option value="graduation-cap" {{ old('icon') == 'graduation-cap' ? 'selected' : '' }}>🎓
                                Education</option>
                            <option value="camera" {{ old('icon') == 'camera' ? 'selected' : '' }}>📷 Photography</option>
                            <option value="tag" {{ old('icon') == 'tag' ? 'selected' : '' }}>🏷️ General</option>
                        </select>
                        @error('icon')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div> --}}

                    <div>
                        <label class="block text-gray-700 text-sm font-medium mb-2">Color *</label>
                        <select name="color"
                            class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 @error('color') border-red-500 @enderror">
                            <option value="">Select a color</option>
                            <option value="indigo" {{ old('color') == 'indigo' ? 'selected' : '' }}>🟣 Indigo</option>
                            <option value="blue" {{ old('color') == 'blue' ? 'selected' : '' }}>🔵 Blue</option>
                            <option value="green" {{ old('color') == 'green' ? 'selected' : '' }}>🟢 Green</option>
                            <option value="red" {{ old('color') == 'red' ? 'selected' : '' }}>🔴 Red</option>
                            <option value="yellow" {{ old('color') == 'yellow' ? 'selected' : '' }}>🟡 Yellow</option>
                            <option value="purple" {{ old('color') == 'purple' ? 'selected' : '' }}>🟣 Purple</option>
                            <option value="pink" {{ old('color') == 'pink' ? 'selected' : '' }}>🌸 Pink</option>
                            <option value="orange" {{ old('color') == 'orange' ? 'selected' : '' }}>🟠 Orange</option>
                            <option value="teal" {{ old('color') == 'teal' ? 'selected' : '' }}>💚 Teal</option>
                            <option value="cyan" {{ old('color') == 'cyan' ? 'selected' : '' }}>💙 Cyan</option>
                        </select>
                        @error('color')
                            <p class="text-red-500 text-xs mt-1">{{ $message }}</p>
                        @enderror
                    </div>
                </div>

                {{-- <!-- Color Preview -->
                <div class="mb-4 p-4 bg-gray-50 rounded-lg">
                    <label class="block text-gray-700 text-sm font-medium mb-3">Color Preview</label>
                    <div class="flex flex-wrap gap-2">
                        @foreach(['indigo', 'blue', 'green', 'red', 'yellow', 'purple', 'pink', 'orange', 'teal', 'cyan'] as $color)
                            <div class="w-8 h-8 rounded-full bg-{{ $color }}-500 cursor-pointer color-option hover:ring-2 hover:ring-offset-2 hover:ring-gray-400 transition"
                                data-color="{{ $color }}" onclick="selectColor('{{ $color }}')"
                                title="{{ ucfirst($color) }}"></div>
                        @endforeach
                    </div>
                </div> --}}

                <!-- Buttons -->
                <div class="flex justify-end space-x-3 border-t pt-6">
                    <a href="{{ route('admin.categories') }}"
                        class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50 transition">
                        Cancel
                    </a>
                    <button type="submit"
                        class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700 transition flex items-center">
                        <i class="fa-solid fa-plus mr-2"></i>
                        Create Category
                    </button>
                </div>
            </form>
        </div>
    </div>
</x-admin-layout>