

<?php $__env->startSection('title', 'Home - BlogSpace'); ?>

<?php $__env->startSection('content'); ?>
<!-- Hero Section -->
<div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
    <div class="max-w-7xl mx-auto py-12 px-4 sm:py-16 sm:px-6 lg:px-8">
        <div class="text-center">
            <h1 class="text-4xl font-extrabold sm:text-5xl md:text-6xl">
                Welcome to BlogSpace
            </h1>
            <p class="mt-6 max-w-2xl mx-auto text-xl">
                Discover stories, thinking, and expertise from writers on any topic.
            </p>
            <div class="mt-10">
                <a href="<?php echo e(route('blog.articles')); ?>" class="inline-flex items-center px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-600 bg-white hover:bg-gray-50 transition">
                    Start Reading
                    <i class="fa-solid fa-arrow-right ml-2"></i>
                </a>
            </div>
        </div>
    </div>
</div>

<!-- Featured Posts -->
<div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
    <div class="text-center mb-12">
        <h2 class="text-3xl font-bold text-gray-900">Featured Articles</h2>
        <p class="mt-4 text-gray-600">Hand-picked articles for you</p>
    </div>

    <div class="grid grid-cols-1 md:grid-cols-3 gap-8">
        <?php $__currentLoopData = $featuredPosts ?? []; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="bg-white rounded-lg shadow-lg overflow-hidden hover:shadow-xl transition">
            <img src="<?php echo e($post->image ?? 'https://via.placeholder.com/400x200'); ?>" alt="<?php echo e($post->title); ?>" class="w-full h-48 object-cover">
            <div class="p-6">
                <div class="flex items-center text-sm text-gray-500 mb-2">
                    <span class="bg-indigo-100 text-indigo-800 px-2 py-1 rounded"><?php echo e($post->category); ?></span>
                    <span class="mx-2">•</span>
                    <span><?php echo e($post->created_at->diffForHumans()); ?></span>
                </div>
                <h3 class="text-xl font-semibold text-gray-900 mb-2"><?php echo e($post->title); ?></h3>
                <p class="text-gray-600 mb-4"><?php echo e(Str::limit($post->excerpt, 100)); ?></p>
                <div class="flex items-center justify-between">
                    <div class="flex items-center">
                        <img src="<?php echo e($post->author->avatar ?? 'https://ui-avatars.com/api/?name='.urlencode($post->author->name)); ?>" class="h-8 w-8 rounded-full mr-2">
                        <span class="text-sm text-gray-700"><?php echo e($post->author->name); ?></span>
                    </div>
                    <a href="<?php echo e(route('blog.post', $post->slug)); ?>" class="text-indigo-600 hover:text-indigo-800 text-sm font-medium">Read More →</a>
                </div>
            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
</div>

<!-- Popular Categories -->
<div class="bg-gray-100 py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-12">
            <h2 class="text-3xl font-bold text-gray-900">Popular Categories</h2>
            <p class="mt-4 text-gray-600">Explore articles by topic</p>
        </div>

        <div class="grid grid-cols-2 md:grid-cols-4 gap-4">
            <?php $__currentLoopData = ['Technology', 'Lifestyle', 'Travel', 'Food', 'Health', 'Business', 'Sports', 'Entertainment']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#" class="bg-white rounded-lg p-6 text-center hover:shadow-md transition group">
                <i class="fa-solid fa-<?php echo e($category === 'Technology' ? 'laptop-code' : 'tag'); ?> text-3xl text-indigo-600 mb-3"></i>
                <h3 class="text-lg font-semibold text-gray-900 group-hover:text-indigo-600"><?php echo e($category); ?></h3>
                <p class="text-sm text-gray-500 mt-1"><?php echo e(rand(10, 50)); ?> articles</p>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<!-- Newsletter -->
<div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
    <div class="bg-indigo-700 rounded-2xl shadow-xl overflow-hidden">
        <div class="px-6 py-12 sm:px-12 lg:py-16 lg:px-16 text-center">
            <h2 class="text-3xl font-bold text-white">Subscribe to Our Newsletter</h2>
            <p class="mt-4 text-indigo-100 text-lg">Get the latest posts delivered right to your inbox.</p>
            <form class="mt-8 sm:flex justify-center">
                <input type="email" placeholder="Enter your email" class="w-full sm:w-96 px-5 py-3 border border-transparent rounded-md text-base focus:outline-none focus:ring-2 focus:ring-white">
                <button type="submit" class="mt-3 sm:mt-0 sm:ml-3 w-full sm:w-auto px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-white">
                    Subscribe
                </button>
            </form>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan\Desktop\Web-Development\Projects\blog\resources\views\blog\home.blade.php ENDPATH**/ ?>