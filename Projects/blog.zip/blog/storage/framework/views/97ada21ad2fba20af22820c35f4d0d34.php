<?php if (isset($component)) { $__componentOriginal91fdd17964e43374ae18c674f95cdaa3 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3 = $attributes; } ?>
<?php $component = App\View\Components\AdminLayout::resolve([] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('admin-layout'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\App\View\Components\AdminLayout::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white flex justify-between items-center">
         <
        <div class="max-w-7xl mx-auto py-12 px-4 sm:py-16 sm:px-6 lg:px-8 text-center">
            <h1 class="text-4xl font-extrabold sm:text-5xl md:text-6xl">Edit Category</h1>
            <p class="mt-4 text-xl text-indigo-100">Update category information</p>
        </div>
        <div>
            <a href="<?php echo e(route('admin.categories')); ?>"
                class="inline-block bg-white text-indigo-600 px-6 py-3 rounded-lg hover:bg-indigo-50 transition font-medium shadow-lg">
                Back to Categories
            </a>
        </div>
    </div>

    <div class="max-w-3xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div class="bg-white rounded-lg shadow">
            <div class="px-6 py-4 border-b border-gray-200">
                <h3 class="text-lg font-semibold text-gray-900">Edit Category: <?php echo e($category->name); ?></h3>
            </div>

            <form action="<?php echo e(route('admin.categories.update', $category)); ?>" method="POST" class="p-6">
                <?php echo csrf_field(); ?>
                <?php echo method_field('PUT'); ?>

                <!-- Name -->
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-medium mb-2">Category Name *</label>
                    <input type="text" name="name" value="<?php echo e(old('name', $category->name)); ?>" 
                           class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> border-red-500 <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <p class="text-red-500 text-xs mt-1"><?php echo e($message); ?></p>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>

                <!-- Description -->
                <div class="mb-4">
                    <label class="block text-gray-700 text-sm font-medium mb-2">Description</label>
                    <textarea name="description" rows="3" 
                              class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500"><?php echo e(old('description', $category->description)); ?></textarea>
                </div>

                <!-- Icon and Color -->
                <div class="grid grid-cols-1 md:grid-cols-2 gap-4 mb-4">
                    

                    <div>
                        <label class="block text-gray-700 text-sm font-medium mb-2">Color *</label>
                        <select name="color" class="w-full px-4 py-2 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500">
                            <option value="indigo" <?php echo e($category->color == 'indigo' ? 'selected' : ''); ?>>Indigo</option>
                            <option value="blue" <?php echo e($category->color == 'blue' ? 'selected' : ''); ?>>Blue</option>
                            <option value="green" <?php echo e($category->color == 'green' ? 'selected' : ''); ?>>Green</option>
                            <option value="red" <?php echo e($category->color == 'red' ? 'selected' : ''); ?>>Red</option>
                            <option value="yellow" <?php echo e($category->color == 'yellow' ? 'selected' : ''); ?>>Yellow</option>
                            <option value="purple" <?php echo e($category->color == 'purple' ? 'selected' : ''); ?>>Purple</option>
                            <option value="pink" <?php echo e($category->color == 'pink' ? 'selected' : ''); ?>>Pink</option>
                            <option value="orange" <?php echo e($category->color == 'orange' ? 'selected' : ''); ?>>Orange</option>
                            <option value="teal" <?php echo e($category->color == 'teal' ? 'selected' : ''); ?>>Teal</option>
                            <option value="cyan" <?php echo e($category->color == 'cyan' ? 'selected' : ''); ?>>Cyan</option>
                        </select>
                    </div>
                </div>

                <!-- Featured -->
                

                <!-- Buttons -->
                <div class="flex justify-end space-x-3">
                    <a href="<?php echo e(route('admin.categories')); ?>" 
                       class="px-4 py-2 border border-gray-300 rounded-lg text-gray-700 hover:bg-gray-50">
                        Cancel
                    </a>
                    <button type="submit" 
                            class="px-4 py-2 bg-indigo-600 text-white rounded-lg hover:bg-indigo-700">
                        Update Category
                    </button>
                </div>
            </form>
        </div>
    </div>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $attributes = $__attributesOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__attributesOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3)): ?>
<?php $component = $__componentOriginal91fdd17964e43374ae18c674f95cdaa3; ?>
<?php unset($__componentOriginal91fdd17964e43374ae18c674f95cdaa3); ?>
<?php endif; ?><?php /**PATH C:\Users\Mahadi Hassan\Desktop\Web-Development\Projects\blog\resources\views\admin\categories\edit.blade.php ENDPATH**/ ?>