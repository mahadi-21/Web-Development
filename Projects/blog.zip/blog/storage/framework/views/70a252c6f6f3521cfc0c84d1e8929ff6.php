

<?php $__env->startSection('title', 'Categories - BlogSpace'); ?>

<?php $__env->startSection('content'); ?>
<!-- Page Header -->
<div class="bg-gradient-to-r from-indigo-600 to-purple-600 text-white">
    <div class="max-w-7xl mx-auto py-12 px-4 sm:py-16 sm:px-6 lg:px-8">
        <div class="text-center">
            <h1 class="text-4xl font-extrabold sm:text-5xl md:text-6xl">
                All Categories
            </h1>
            <p class="mt-6 max-w-2xl mx-auto text-xl">
                Explore our diverse range of topics and find content that interests you
            </p>
        </div>
    </div>
</div>

<!-- Categories Grid -->
<div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
    <!-- Search and Filter -->
    <div class="mb-12">
        <div class="max-w-xl mx-auto">
            <div class="relative">
                <input type="text" 
                       placeholder="Search categories..." 
                       class="w-full px-4 py-3 pl-12 pr-4 border border-gray-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent"
                       id="categorySearch">
                <i class="fa-solid fa-magnifying-glass absolute left-4 top-3.5 text-gray-400"></i>
            </div>
        </div>
    </div>

    <!-- Categories Stats -->
    <div class="grid grid-cols-1 sm:grid-cols-2 md:grid-cols-4 gap-6 mb-12">
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="bg-indigo-100 rounded-full p-3">
                    <i class="fa-solid fa-folder-open text-2xl text-indigo-600"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-500 text-sm">Total Categories</p>
                    <p class="text-2xl font-bold text-gray-900"><?php echo e($total_categories ?? 0); ?></p>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="bg-green-100 rounded-full p-3">
                    <i class="fa-solid fa-file-lines text-2xl text-green-600"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-500 text-sm">Total Articles</p>
                    <p class="text-2xl font-bold text-gray-900"><?php echo e($total_articles ?? 0); ?></p>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="bg-purple-100 rounded-full p-3">
                    <i class="fa-solid fa-users text-2xl text-purple-600"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-500 text-sm">Active Authors</p>
                    <p class="text-2xl font-bold text-gray-900"><?php echo e($active_authors ?? 0); ?></p>
                </div>
            </div>
        </div>
        
        <div class="bg-white rounded-lg shadow p-6">
            <div class="flex items-center">
                <div class="bg-yellow-100 rounded-full p-3">
                    <i class="fa-solid fa-eye text-2xl text-yellow-600"></i>
                </div>
                <div class="ml-4">
                    <p class="text-gray-500 text-sm">Monthly Views</p>
                    <p class="text-2xl font-bold text-gray-900"><?php echo e(number_format($monthlyViews ?? 12500)); ?></p>
                </div>
            </div>
        </div>
    </div>

    <!-- Featured Categories -->
    

    <!-- All Categories -->
    <div>
        <div class="flex justify-between items-center mb-6">
            <h2 class="text-2xl font-bold text-gray-900">All Categories</h2>
            <div class="flex space-x-2">
                <select class="border border-gray-300 rounded-lg px-4 py-2 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500">
                    <option>Sort by: Popular</option>
                    <option>Sort by: Name</option>
                    <option>Sort by: Newest</option>
                    <option>Sort by: Articles Count</option>
                </select>
            </div>
        </div>

        <div class="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="" 
               class="bg-white rounded-lg shadow p-6 hover:shadow-lg transition group">
                <div class="flex items-start justify-between">
                    <div class="flex items-center space-x-4">
                        <div class="bg-<?php echo e($category['color']); ?>-100 rounded-lg p-3 group-hover:scale-110 transition">
                            <i class="fa-solid fa-<?php echo e($category['icon']); ?> text-2xl text-<?php echo e($category['color']); ?>-600"></i>
                        </div>
                        <div>
                            <h3 class="text-lg font-semibold text-gray-900 group-hover:text-indigo-600">
                                <?php echo e($category['name']); ?>

                            </h3>
                            <p class="text-sm text-gray-500 mt-1"><?php echo e($category['count']); ?> articles</p>
                        </div>
                    </div>
                    <i class="fa-solid fa-chevron-right text-gray-400 group-hover:text-indigo-600 group-hover:translate-x-1 transition"></i>
                </div>
                
                <!-- Recent articles in this category -->
                <div class="mt-4 pt-4 border-t border-gray-100">
                    <p class="text-xs text-gray-400 mb-2">Recent articles:</p>
                    <div class="space-y-2">
                        <div class="flex items-center text-sm">
                            <span class="w-2 h-2 bg-<?php echo e($category['color']); ?>-400 rounded-full mr-2"></span>
                            <span class="text-gray-600 truncate">Latest post in <?php echo e($category['name']); ?></span>
                        </div>
                        <div class="flex items-center text-sm">
                            <span class="w-2 h-2 bg-<?php echo e($category['color']); ?>-300 rounded-full mr-2"></span>
                            <span class="text-gray-600 truncate">Another popular article</span>
                        </div>
                    </div>
                </div>
            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>

    <!-- Pagination -->
    <div class="mt-12">
        <?php echo e($categories->links()); ?>

    </div>
</div>

<!-- Popular Tags Section -->
<div class="bg-gray-100 py-12">
    <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div class="text-center mb-8">
            <h2 class="text-2xl font-bold text-gray-900">Popular Tags</h2>
            <p class="text-gray-600 mt-2">Browse articles by specific topics</p>
        </div>
        
        <div class="flex flex-wrap justify-center gap-3">
            <?php $__currentLoopData = ['Laravel', 'PHP', 'JavaScript', 'Vue.js', 'React', 'Tailwind CSS', 'AI', 'Machine Learning', 'Web Development', 'Mobile Apps', 'UX Design', 'Digital Marketing', 'SEO', 'Cloud Computing', 'DevOps', 'Cybersecurity']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tag): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <a href="#" class="bg-white px-4 py-2 rounded-full text-sm text-gray-700 hover:bg-indigo-600 hover:text-white transition shadow-sm">
                #<?php echo e($tag); ?>

            </a>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
    </div>
</div>

<!-- Newsletter Section -->
<div class="max-w-7xl mx-auto py-12 px-4 sm:px-6 lg:px-8">
    <div class="bg-indigo-700 rounded-2xl shadow-xl overflow-hidden">
        <div class="px-6 py-12 sm:px-12 lg:py-16 lg:px-16">
            <div class="grid grid-cols-1 lg:grid-cols-2 gap-8 items-center">
                <div>
                    <h2 class="text-3xl font-bold text-white">Stay Updated</h2>
                    <p class="mt-4 text-indigo-100 text-lg">
                        Get notified when we publish new articles in your favorite categories.
                    </p>
                </div>
                <div>
                    <form class="sm:flex">
                        <input type="email" 
                               placeholder="Enter your email" 
                               class="w-full px-5 py-3 border border-transparent rounded-md text-base focus:outline-none focus:ring-2 focus:ring-white">
                        <button type="submit" 
                                class="mt-3 sm:mt-0 sm:ml-3 w-full sm:w-auto px-6 py-3 border border-transparent text-base font-medium rounded-md text-indigo-700 bg-white hover:bg-indigo-50 focus:outline-none focus:ring-2 focus:ring-white">
                            Subscribe
                        </button>
                    </form>
                    <p class="mt-3 text-xs text-indigo-200">
                        We respect your privacy. Unsubscribe at any time.
                    </p>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->startPush('scripts'); ?>
<script>
    // Category search functionality
    document.getElementById('categorySearch').addEventListener('keyup', function() {
        let searchTerm = this.value.toLowerCase();
        let categories = document.querySelectorAll('.grid > a');
        
        categories.forEach(category => {
            let categoryName = category.querySelector('h3').textContent.toLowerCase();
            if (categoryName.includes(searchTerm)) {
                category.style.display = 'block';
            } else {
                category.style.display = 'none';
            }
        });
    });
</script>
<?php $__env->stopPush(); ?>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.blog', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\Users\Mahadi Hassan\Desktop\Web-Development\Projects\blog\resources\views\blog\categories.blade.php ENDPATH**/ ?>